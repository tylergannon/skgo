// Package gen turns Go remote-function declarations into the files SvelteKit
// and Go each need: the `.remote.ts` module kit compiles, the TypeScript types
// its callers see, and the Go registration that answers the calls.
//
// The authoring model is the one in the brief. A developer writes an ordinary
// Go function in a `*.remote.go` file, colocated with the routes that use it,
// and marks it:
//
//	func getTodos(ctx context.Context) ([]Todo, error) { ... }
//
//	var _ = skgo.Query(getTodos)
//
// Nothing else is hand-written. `skgo generate` reads the marker with go/types
// — never by matching source text — takes the argument and result types out of
// the marked function's own signature, and emits everything else. The argument
// is optional there because it is optional in kit: `query(fn)` accepts
// `(arg?) => Output`, so a query that takes nothing is written taking nothing.
package gen

import (
	"fmt"
	"go/parser"
	"go/token"
	"go/types"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/tylergannon/polytype/goload"
	"golang.org/x/tools/go/packages"
)

// Config describes one app.
type Config struct {
	// CacheDir enables an optional persistent cache of successful generation
	// plans for Run. Empty uses SKGO_CACHE_DIR when set, otherwise the user cache
	// directory; "off" disables it.
	// Prepare and Check always analyze source.
	// Custom package loaders and snapshots bypass the disk cache. Local module
	// source is captured before analysis. Installed toolchains, versioned module
	// cache and Node packages must retain their installed immutable contents.
	// External source views, vendoring and reached local cgo packages bypass
	// persistence. Cache corruption or unavailable storage does not prevent Run.
	CacheDir    string
	cache       *generationCache
	kitMetadata *kitRouteMetadata
	// RouteMetadata supplies Kit-owned route discovery and frontend-validated
	// matcher names. Generation validates the paired Go declarations.
	RouteMetadata *RouteMetadata
	sourceView    *generationSourceView
	analysisView  *goload.View
	// Packages contains immutable, caller-loaded package snapshots. Incompatible
	// snapshots are ignored and the current sources are loaded normally.
	Packages []*PackageSnapshot
	// Session shares compatible Go analysis within a caller-owned invocation.
	// Persistent cache hits do not load anything through it. Keep source and
	// returned compiler objects immutable while consumers use them. Nil uses
	// the ordinary loader; supplied snapshots and LoadPackages take precedence.
	Session *goload.Session
	// LoadPackages optionally replaces the fallback loader. It receives the
	// current logical source overlay before temporary staging. Nil uses the default loader.
	LoadPackages PackageLoader
	// OnPackageLoad observes requests before session reuse or temporary staging.
	// It is not called for compatible snapshot hits or persistent cache hits,
	// and must not mutate its arguments. Session.Stats reports actual shared work.
	OnPackageLoad func(*packages.Config, []string)

	localsDir     string
	LocalsPackage string
	LocalsType    string
	HookPackage   string
	HookSymbol    string
	generation    *generatedOutput
	matchers      map[string]goParamMatcher
	loadParams    map[string]*routeLoadParams
	frontendFiles map[string]struct{}
	// produced is every path this run wrote or confirmed unchanged, so that
	// pruneStaleArtifacts can tell what is left over.
	produced map[string]struct{}
	// Web is the vite root: the directory holding `src/` and the app's
	// package.json. Every `.remote.ts` path is relative to it, because that is
	// what kit hashes into a remote function's id.
	Web string
	// Out is the directory of the generated bindings package, normally
	// `<app>/generated`. It must be inside the same Go module as the remote
	// functions.
	Out string
	// Package is the name of the generated bindings package. It defaults to
	// the base name of Out.
	Package string
	// SwiftOut is the generated Swift source file. SwiftRemotes selects ordinary
	// queries and commands by Vite-root-relative module path plus #export.
	// Selected functions adopt the finite native number profile in their shared
	// Go handlers: unsafe integers are refused for browser and native callers.
	SwiftOut     string
	SwiftRemotes []string
	// Logf receives one line per file written. It may be nil.
	Logf func(format string, args ...any)
	// ReadOnly makes package loading verify generated route links instead of
	// synchronizing them. It is used only by Check.
	ReadOnly bool
	// Language selects the frontend language of the modules skgo writes. The
	// zero value asks Run to choose from the app: a tsconfig.json means
	// TypeScript, a jsconfig.json JavaScript, and neither defaults to
	// TypeScript. TypeScript is the default, and its output does not change.
	Language Language
}

// Prepared owns one generation invocation and its temporary source views.
// Call Close when finished, including when the caller's analysis fails.
// The package graph and generated output must not be mutated concurrently.
type Prepared struct {
	cfg         Config
	files       []string
	app         *app
	closed, ran bool
}

// Prepare resolves the current generated source views and analyzes the app.
// Embedding tools may inspect Packages before Run without loading them again.
func Prepare(cfg Config) (*Prepared, error) { return prepare(cfg) }

// Packages returns the discovery graph used for routes and remote functions.
// Imported type identities belong to the same go/types universe. Dependency
// syntax is present only when supplied by a compatible caller bundle.
// Treat the graph as immutable. Source views remain valid until Close.
func (p *Prepared) Packages() []*packages.Package {
	if p == nil || p.app == nil {
		return nil
	}
	return append([]*packages.Package(nil), p.app.loadedPackages...)
}

// Close releases the invocation's temporary source views. It is idempotent.
func (p *Prepared) Close() {
	if p != nil && !p.closed {
		p.closed = true
		if p.cfg.generation != nil {
			p.cfg.generation.close()
		}
	}
}

// Run scans, generates, and reports what it wrote.
func Run(cfg Config) error {
	if cfg.CacheDir == "" {
		cfg.CacheDir = os.Getenv("SKGO_CACHE_DIR")
	}
	if cfg.CacheDir == "" {
		if root, err := os.UserCacheDir(); err == nil {
			cfg.CacheDir = filepath.Join(root, "skgo", "generate")
		}
	}
	if cfg.CacheDir != "" && cfg.CacheDir != "off" && !cfg.ReadOnly && cfg.LoadPackages == nil && len(cfg.Packages) == 0 {
		return runCached(cfg)
	}
	return runUncached(cfg)
}

func runUncached(cfg Config) error {
	p, err := Prepare(cfg)
	if err != nil {
		return err
	}
	defer p.Close()
	return p.Run()
}

func prepare(cfg Config) (prepared *Prepared, err error) {
	cfg, err = normalizeConfig(cfg)
	if err != nil {
		return nil, err
	}
	web := cfg.Web

	files, err := findSourceFiles(web)
	if err != nil {
		return nil, err
	}
	cfg.generation, err = newGeneration(cfg)
	if err != nil {
		return nil, err
	}
	defer func() {
		if err != nil {
			cfg.generation.close()
		}
	}()
	if err := prepareLocals(&cfg); err != nil {
		return nil, err
	}
	if cfg.loadParams, err = prepareLoadParams(&cfg, files); err != nil {
		return nil, err
	}
	if err := validateHook(cfg); err != nil {
		return nil, err
	}
	if err := (&app{cfg: cfg}).writeRequestBoundary(); err != nil {
		return nil, err
	}
	var a *app
	if len(files) > 0 {
		a, err = loadApp(cfg, files)
		if err != nil {
			return nil, err
		}
	}
	return &Prepared{cfg: cfg, files: files, app: a}, nil
}

func normalizeConfig(cfg Config) (Config, error) {
	if cfg.RouteMetadata != nil && cfg.kitMetadata == nil {
		cfg.kitMetadata = cloneRouteMetadata(cfg.RouteMetadata)
	}
	if cfg.Logf == nil {
		cfg.Logf = func(string, ...any) {}
	}
	web, err := filepath.Abs(cfg.Web)
	if err != nil {
		return cfg, err
	}
	out, err := filepath.Abs(cfg.Out)
	if err != nil {
		return cfg, err
	}
	cfg.Web, cfg.Out = web, out
	if (cfg.SwiftOut == "") != (len(cfg.SwiftRemotes) == 0) {
		return cfg, fmt.Errorf("skgo: --swift-out and --swift-remote must be provided together")
	}
	if cfg.SwiftOut != "" {
		cfg.SwiftOut, err = filepath.Abs(cfg.SwiftOut)
		if err != nil {
			return cfg, err
		}
		if filepath.Ext(cfg.SwiftOut) != ".swift" {
			return cfg, fmt.Errorf("skgo: --swift-out must name a .swift file")
		}
	}
	cfg.frontendFiles = map[string]struct{}{}
	cfg.produced = map[string]struct{}{}
	if cfg.Language == LanguageAuto {
		cfg.Language = detectLanguage(web)
	}
	if cfg.Package == "" {
		cfg.Package = filepath.Base(out)
	}
	if fi, err := os.Stat(filepath.Join(web, "src")); err != nil || !fi.IsDir() {
		return cfg, fmt.Errorf("skgo: %s does not look like a vite root: no src/ directory", web)
	}

	// The adapter kit builds the frontend with is an ordinary npm package the
	// app installed, and it is the same contract as the stubs and the remote
	// list below: what the adapter writes, this module's Go reads. Generating
	// against one this module cannot read the output of is the mistake worth
	// catching before a full frontend build rather than after it.
	if err := checkInstalledAdapter(cfg); err != nil {
		return cfg, err
	}
	return cfg, nil
}

// Run publishes output from this prepared invocation. Call it at most once,
// without changing source files after Prepare. Use a new Prepare after edits.
func (p *Prepared) Run() error {
	if p == nil || p.cfg.generation == nil || p.closed || p.ran {
		return fmt.Errorf("skgo: prepared generation is closed or already run")
	}
	p.ran = true
	cfg, files := p.cfg, p.files
	if len(files) == 0 {
		if len(cfg.SwiftRemotes) != 0 {
			return fmt.Errorf("skgo: no remote functions match the Swift selection")
		}
		// An application does not need demo or placeholder server behavior. The
		// empty bindings are still a real contract: the Go server imports these
		// lists, and the adapter compares skgo.remotes.json with the frontend it
		// built. When the developer later adds a Go endpoint, the ordinary path
		// below overwrites both files with its generated registration.
		empty := &app{cfg: cfg}
		if empty.hasPrerenderWork() {
			var err error
			empty.hostDir, empty.hostModule, err = moduleOf(cfg.Out)
			if err != nil {
				return err
			}
			if err := empty.writePrerenderCommand(); err != nil {
				return err
			}
		}
		if err := empty.writeEnvironment(); err != nil {
			return err
		}
		if err := empty.writeAppBindings(); err != nil {
			return err
		}
		if err := empty.writeFormClients(); err != nil {
			return err
		}
		if err := empty.writeRemoteList(); err != nil {
			return err
		}
		if err := pruneStaleArtifacts(cfg); err != nil {
			return err
		}
		return finishGeneration(cfg)
	}

	app := p.app
	if len(app.remotes) == 0 && len(app.loads) == 0 && len(app.actions) == 0 && len(app.endpoints) == 0 && len(app.transported) == 0 && app.environment == nil {
		return fmt.Errorf("skgo: found %d source file(s) but no skgo.Query, skgo.Command, skgo.LiveQuery, skgo.Load or skgo.GET declaration in any of them", len(files))
	}
	if err := app.writeEnvironment(); err != nil {
		return err
	}
	if err := app.checkEndpointDuplicates(); err != nil {
		return err
	}

	if err := app.checkFileUsage(); err != nil {
		return err
	}
	if err := app.checkWireFields(); err != nil {
		return err
	}
	if err := app.checkPrerenderedActions(); err != nil {
		return err
	}

	// Types first: the stubs import what polytype emits, so a type that
	// cannot be projected must stop generation before any stub is written.
	if err := app.declareLoadTypes(); err != nil {
		return err
	}
	for _, action := range app.actions {
		if action.out != nil && containsDeferred(action.out) {
			return fmt.Errorf("skgo: %s: action %s cannot return a Deferred", action.pos, action.name)
		}
		for _, typ := range []types.Type{action.out, action.failure} {
			if typ == nil {
				continue
			}
			if _, err := app.loadFields(&loadFn{out: typ, pos: action.pos}); err != nil {
				return fmt.Errorf("skgo: action %s: %w", action.name, err)
			}
		}
	}
	if err := app.generateTypes(); err != nil {
		return err
	}
	if err := app.writeStubs(); err != nil {
		return err
	}
	if err := app.writeLoadStubs(); err != nil {
		return err
	}
	if err := app.writeEndpointStubs(); err != nil {
		return err
	}
	app.planNames()
	if err := app.writePackageBindings(); err != nil {
		return err
	}
	if err := app.planCodecs(); err != nil {
		return err
	}
	if err := app.writeSwiftClient(); err != nil {
		return err
	}
	if err := app.generateCodecs(); err != nil {
		return err
	}
	if err := app.writeAppBindings(); err != nil {
		return err
	}
	if err := app.writePrerenderCommand(); err != nil {
		return err
	}
	if err := app.writeFormClients(); err != nil {
		return err
	}
	if err := app.writeRemoteList(); err != nil {
		return err
	}
	if err := pruneStaleArtifacts(cfg); err != nil {
		return err
	}
	return finishGeneration(cfg)
}

// Generated files are never scanned for authored declarations.
const generatedFileSuffix = "_gen.go"
const generatedRemotesFileName = generatedGoFile

// packageNameOf reads the package clause of a directory's Go source, off
// whichever file states it plainly. It parses the package clause alone,
// never the rest of the file, so a file whose body cannot type-check — the
// very case this exists to work around — still answers.
func packageNameOf(dir string) (string, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return "", err
	}
	fset := token.NewFileSet()
	for _, e := range entries {
		name := e.Name()
		if e.IsDir() || !strings.HasSuffix(name, ".go") || strings.HasSuffix(name, generatedFileSuffix) || strings.HasSuffix(name, "_test.go") {
			continue
		}
		f, err := parser.ParseFile(fset, filepath.Join(dir, name), nil, parser.PackageClauseOnly)
		if err != nil {
			continue
		}
		return f.Name.Name, nil
	}
	return "", fmt.Errorf("skgo: no source file in %s states its own package name", dir)
}

// loadFileNames are the two file names that carry a server load. A route
// directory holds one `+page.server.ts` and one `+layout.server.ts` at most, so
// the Go file that generates each is named for it — minus the `+`, which Go
// refuses in a file name.
var loadFileNames = map[string]string{
	"page.server.go":   "+page.server.ts",
	"layout.server.go": "+layout.server.ts",
}

// hooksFileName is the app's universal hooks, beside kit's own `src/hooks.ts`.
// Kit's `transport` is a universal hook — the browser needs `decode` and the
// server needs `encode` — so the Go half is declared where the TypeScript half
// is, and one file per app is all kit allows.
const hooksFileName = "hooks.go"

// findSourceFiles collects every `*.remote.go`, `page.server.go`,
// `layout.server.go` and `server.go` under `<web>/src`, skipping the
// directories neither Go nor a developer means to be scanned.
func findSourceFiles(web string) ([]string, error) {
	var found []string
	src := filepath.Join(web, "src")
	err := filepath.WalkDir(src, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		name := d.Name()
		if d.IsDir() {
			if path == src {
				return nil
			}
			if name == "node_modules" || strings.HasPrefix(name, ".") || strings.HasPrefix(name, "_") {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasSuffix(name, generatedFileSuffix) {
			return nil
		}
		_, isLoad := loadFileNames[name]
		if !isLoad && name != serverFileName && name != hooksFileName && path != filepath.Join(src, "env.go") && !strings.HasSuffix(name, ".remote.go") {
			return nil
		}
		found = append(found, path)
		return nil
	})
	if err != nil {
		return nil, err
	}
	sort.Strings(found)
	return found, nil
}

// webRel is the posix path of file relative to the vite root. Kit hashes this
// string, so it must use forward slashes on every platform.
func webRel(web, file string) (string, error) {
	rel, err := filepath.Rel(web, file)
	if err != nil {
		return "", err
	}
	if strings.HasPrefix(rel, "..") {
		return "", fmt.Errorf("skgo: %s is outside the vite root %s", file, web)
	}
	return filepath.ToSlash(rel), nil
}
